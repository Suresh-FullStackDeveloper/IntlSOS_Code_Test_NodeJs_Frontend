import { Tutorial } from './doctors.model';

describe('Tutorial', () => {
  it('should create an instance', () => {
    expect(new Tutorial()).toBeTruthy();
  });
});
