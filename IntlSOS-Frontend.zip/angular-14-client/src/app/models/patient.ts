export class Patient {
    id : string;
    name : string;
    ic : string;
    age : number;
    sex : string;
    hospital_id : string;
    diagnosis_history: object;
}