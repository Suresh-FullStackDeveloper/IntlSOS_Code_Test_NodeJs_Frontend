export class Doctor {
    id : string;
    name : string;
    ic : string;
    position : string;
    age : number;
    email : string;
    contact_number : string;
    hospital_id : string;
}