import { Component, OnInit } from '@angular/core';
import { Doctors } from 'src/app/models/doctors.model';
import { DoctorsService } from 'src/app/services/doctors.service';

@Component({
  selector: 'app-doctors-list',
  templateUrl: './doctors-list.component.html',
  styleUrls: ['./doctors-list.component.css']
})
export class DoctorsListComponent implements OnInit {

  tutorials?: Doctors[];
  currentTutorial: Doctors = {};
  currentIndex = -1;
  title = '';

  constructor(private doctorsService: DoctorsService) { }

  ngOnInit(): void {
    this.retrieveDoctors();
  }

  retrieveDoctors(): void {
    this.doctorsService.getAll()
      .subscribe({
        next: (data) => {
          this..doctors = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

  refreshList(): void {
    this.retrieveDoctors();
    this.currentDoctors = {};
    this.currentIndex = -1;
  }

  setActiveDoctors(doctors: Doctors, index: number): void {
    this.currentDoctors = doctors;
    this.currentIndex = index;
  }

  removeAllDoctors(): void {
    this.doctorsService.deleteAll()
      .subscribe({
        next: (res) => {
          console.log(res);
          this.refreshList();
        },
        error: (e) => console.error(e)
      });
  }

  searchTitle(): void {
    this.currentDoctors = {};
    this.currentIndex = -1;

    this.doctorsService.findByTitle(this.title)
      .subscribe({
        next: (data) => {
          this.doctors = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

}