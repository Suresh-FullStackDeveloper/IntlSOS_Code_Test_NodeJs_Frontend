import { Component } from '@angular/core';
import { Doctors } from 'src/app/models/doctors.model';
import { DoctorsService } from 'src/app/services/doctors.service';

@Component({
  selector: 'app-add-doctors',
  templateUrl: './add-doctors.component.html',
  styleUrls: ['./add-doctors.component.css']
})
export class AddTutorialComponent {

  doctors: Doctors = {
    title: '',
    description: '',
    published: false
  };
  submitted = false;

  constructor(private tutorialService: DoctorsService) { }

  saveDoctors(): void {
    const data = {
      title: this.doctors.title,
      description: this.doctors.description
    };

    this.tutorialService.create(data)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.submitted = true;
        },
        error: (e) => console.error(e)
      });
  }

  newDoctors(): void {
    this.submitted = false;
    this.doctors = {
      title: '',
      description: '',
      published: false
    };
  }

}