import { Component, Input, OnInit } from '@angular/core';
import { DoctorsService } from 'src/app/services/doctors.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Tutorial } from 'src/app/models/doctors.model';

@Component({
  selector: 'app-Doctors-details',
  templateUrl: './Doctors-details.component.html',
  styleUrls: ['./Doctors-details.component.css']
})
export class DoctorsDetailsComponent implements OnInit {

  @Input() viewMode = false;

  @Input() currentDoctors: Doctors = {
    title: '',
    description: '',
    published: false
  };
  
  message = '';

  constructor(
    private doctorsService: DoctorsService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    if (!this.viewMode) {
      this.message = '';
      this.getDoctors(this.route.snapshot.params["id"]);
    }
  }

  getTutorial(id: string): void {
    this.doctorsService.get(id)
      .subscribe({
        next: (data) => {
          this.currentDoctors = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

  updatePublished(status: boolean): void {
    const data = {
      title: this.currentDoctors.title,
      description: this.currentDoctors.description,
      published: status
    };

    this.message = '';

    this.doctorsService.update(this.currentDoctors.id, data)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.currentDoctors.published = status;
          this.message = res.message ? res.message : 'The status was updated successfully!';
        },
        error: (e) => console.error(e)
      });
  }

  updateDoctors(): void {
    this.message = '';

    this.doctorsService.update(this.currentDoctors.id, this.currentDoctors)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.message = res.message ? res.message : 'This Doctors was updated successfully!';
        },
        error: (e) => console.error(e)
      });
  }

  deleteDoctors(): void {
    this.doctorsService.delete(this.currentDoctors.id)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.router.navigate(['/doctors']);
        },
        error: (e) => console.error(e)
      });
  }

}